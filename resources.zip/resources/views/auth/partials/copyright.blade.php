<p class="text-muted mb-3 mt-3 text-center">Copyright &copy; 2024 - <script> document.write(new Date().getFullYear()); </script>.
All Rights Reserved by <a class="text-dark" target="__blank" href="https://github.com/satriairawan05">Deuwi Satriya Irawan</a>.<br>
Distributed By <a class="text-dark" href="{{ route('landing-page') }}">{{ env('APP_NAME') }}</a></p>
