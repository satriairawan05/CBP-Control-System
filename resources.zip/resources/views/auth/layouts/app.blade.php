@include('auth.partials.header')
<!-- start: page -->
@yield('auth')
<!-- end: page -->
@include('auth.partials.footer')
