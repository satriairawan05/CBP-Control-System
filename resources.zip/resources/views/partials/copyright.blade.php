<div class="copyright_section text-center">
    <div class="copyright_text">Copyright &copy; 2024 - <script>document.write(new Date().getFullYear());</script>
    <br> All Right Reserved By <a href="https://github.com/satriairawan05">Deuwi Satriya Irawan</a>
    <br> Distributed By <a href="https://samaricode.my.id/">SamariCode</a>
    </div>
</div>
